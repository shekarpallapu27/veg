
from __future__ import unicode_literals
from django.contrib.auth.models import User


from django.db import models



# Create your models here.

BOOL_CHOICES = ((True, 'Yes'), (False, 'No'))



class Veg(models.Model):
	v_id = models.AutoField(primary_key=True)
	v_name = models.CharField(max_length=50)
	v_price = models.CharField(max_length=20)

	def __str__(self):
		return self.v_name


class UserProf(models.Model):
	user_id = models.AutoField(primary_key=True)
	u_name = models.CharField(max_length=50)
	u_age = models.IntegerField()
	veg = models.ManyToManyField(Veg,through='VegUserMap')

	def __str__(self):
		return self.u_name



class VegUserMap(models.Model):
    """
    Model representing a SysEdcMap 
    """
    veg_user_map_id = models.AutoField(primary_key=True)
    userprof_map = models.ForeignKey(UserProf)
    veg_map = models.ForeignKey(Veg)
    is_active = models.BooleanField(choices=BOOL_CHOICES,default=False)

    

  
    def __str__(self):

        """
        String for representing the Model object.
        """
        return  self.__class__.__name__