from django.contrib import admin
from app1.models import *

# Register your models here.

# admin.site.register(UserProf)
# admin.site.register(Veg)


class VegInline(admin.TabularInline):                                                                                               
    model = UserProf.veg.through
    extra = 1


class UserProfAdmin(admin.ModelAdmin):

    fileds =  ('u_name', 'u_age')                                                                                       
    list_display = ('u_name', 'u_age')
    list_filter = ('u_name', 'u_age')                                     
    inlines = (VegInline,)
class VegAdmin(admin.ModelAdmin):                                           
    pass 

class VegUserMapAdmin(admin.ModelAdmin):

    fileds =  ('userprof_map', 'veg_map','is_active')                                                                                       
    list_display = ('userprof_map', 'veg_map','is_active')
    list_filter = ('userprof_map', 'veg_map','is_active')                                                                          

admin.site.register(UserProf, UserProfAdmin)                                      
admin.site.register(Veg, VegAdmin)
admin.site.register(VegUserMap, VegUserMapAdmin)                                      
